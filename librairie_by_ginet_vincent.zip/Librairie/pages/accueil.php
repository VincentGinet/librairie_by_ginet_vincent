<?php

?>

<p>Explication du fonctionnnement</p>

<p>Alors pour utiliser le site, vous pouver cliquer que les différents liens qui existe en haut du site, 
qui vous emmeneront vers des pages différentes comme la liste des auteurs, le genre des livre, la liste des livres.</p>

<p>Nb : j'ai une erreur a pour l'ajout (ma fonction execute ne marche pas)</p>
