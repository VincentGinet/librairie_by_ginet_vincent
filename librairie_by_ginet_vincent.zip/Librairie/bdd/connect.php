<?php

$databaseDNS    	= 'mysql:host=localhost;dbname=librairie';
$databaseUsername 	= 'root';



try {
    $db = new PDO($databaseDNS, $databaseUsername);
} catch (PDOException $exception) {
    echo 'Erreur de connexion : ' . $exception->getMessage();
    die();
}

?>