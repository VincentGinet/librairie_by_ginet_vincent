<?php
$db = null;
