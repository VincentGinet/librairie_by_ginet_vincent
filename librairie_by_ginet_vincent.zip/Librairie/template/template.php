<?php include "header.php" ; ?>

<main>
    <h1><?= $title ?></h1>
    <?php echo $contenu ; ?>
</main>

